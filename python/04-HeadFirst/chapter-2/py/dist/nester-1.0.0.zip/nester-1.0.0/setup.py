#! /usr/bin/env python
#coding=utf-8

from distutils.core import setup

setup(
    name = "nester",
    version = "1.0.0",
    py_modules = ["nester"],
    author = "exp",
    author_email = "play00001@126.com",
    url = "http://www.baidu.com",
    description = "py发布测试"
)