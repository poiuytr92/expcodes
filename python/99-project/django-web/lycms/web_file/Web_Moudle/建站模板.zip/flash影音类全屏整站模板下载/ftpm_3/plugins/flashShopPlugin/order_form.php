<?php
$strings = array(
	'store_name' => 'My Virtual Store',
	'subject' => 'New Order form from mygotostore.com',
	'mailBuyer' => $_POST['email'],
	'mailSeller' => 'backup@gotomultimedia.com',
	'subjectForBuyer' => 'Your Order from mygotostore.com',
	'currency' => $_POST['currency'],
	'currency_symbol' => '$',
	'order_number'=>'Order ID',
	'date'=>'Date',
	'to'=>'To: ',
	'zip'=>'Zip Code:',
	'description'=>'Description',
	'price_label'=>'Price Unit.',
	'quantity'=>'Qty',
	'amount_label'=>'Import',
	'subtotal'=>'Subtotal',
	'vat'=>'I.V.A',
	'shipping'=>'Shipping',
	'total'=>'Total',
	'notes'=>'Notes: ',
	'key' =>'aZdthSpLe35F'  //no not change this
);

if($strings['key'] == $_POST['key']){

$email = "";
$email .= '<html>
<head>
<title>E-Mail HTML</title>
<style type="text/css">
body,td,th {
	font-family: Verdana, Geneva, sans-serif;
}
th {
	background-color: #CCC;
	border-top-width: 2px;
	border-bottom-width: 2px;
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: solid;
	border-left-style: solid;
	border-top-color: #999;
	border-bottom-color: #999;
	padding: 10px;
	border-right-width: 0px;
	border-left-width: 0px;
	vertical-align: middle;
}
.cell {
	padding: 10px;
	border-bottom-width: 1px;
	border-bottom-style: solid;
	border-bottom-color: #CCC;
}
.notes {
	padding: 10px;
	background-color: #EEE;
}
</style>
</head>
<body>
<table width="100%" height="100" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="100%" align="left" valign="middle"><h1>'.$strings["store_name"].'</h1></td>
    <td align="right" valign="middle"><table width="400" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="10" align="right" valign="middle"><strong>'.$strings["order_number"].'</strong></td>
        <td width="10" align="left" valign="middle">&nbsp;</td>
        <td align="left" valign="middle">'.saveNumberOrder().'</td>
      </tr>
      <tr>
        <td height="10" align="right" valign="top"><strong>'.$strings["date"].'</strong></td>
        <td>&nbsp;</td>
        <td>'.date('jS \of M Y').'<br />'.date('h:i:s A').'</td>
      </tr>
    </table></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="50%"><h3>'.$strings["to"].'</h3></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>'.$_POST["name"].'</td>
    <td>'.$_POST["company"].'</td>
  </tr>
  <tr>
    <td>'.$strings["mailBuyer"].'</td>
    <td>'.$_POST["address"].'</td>
  </tr>
  <tr>
    <td>'.$_POST["phone"].'</td>
    <td>'.$_POST["city"].'</td>
  </tr>
  <tr>
    <td>'.$strings["zip"].' '.$_POST["zip"].'</td>
    <td>'.$_POST["country"].'</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <th height="60" align="left">'.$strings["description"].'</th>
    <th width="150" height="60" align="right" valign="middle">'.$strings["price_label"].'</th>
    <th width="150" height="60" align="right" valign="middle">'.$strings["quantity"].'</th>
    <th width="150" height="60" align="right" valign="middle">'.$strings["amount_label"].'</th>
  </tr>';  
  
  $cont = 1;
  
  do{
  	
  	$item = 'item_name_'.$cont;
	$item_name = 'item_name_'.$cont;
	$item_number = 'item_number_'.$cont;
	$item_amount = 'amount_'.$cont;
	$item_quantity = 'quantity_'.$cont;  
	
	$email.=' 
	<tr>
    	<td class="cell" valign="middle"><strong>'.$_POST[$item_name].'</strong><br />Product ID:'.$_POST[$item_number].'</td>
    	<td class="cell" width="150" align="right" valign="middle">'.$strings['currency_symbol'].''.$_POST[$item_amount].'</td>
    	<td class="cell" width="150" align="right" valign="middle">'.$_POST[$item_quantity].'</td>
    	<td class="cell" width="150" align="right" valign="middle">'.$strings['currency_symbol'].''.($_POST[$item_amount]*$_POST[$item_quantity]).'</td>
  	</tr>';
  	$cont++;
  }while($cont < $_POST["totalItems"]+1);
  
  
  $email.='
  <tr>
    <td valign="middle">&nbsp;</td>
    <td colspan="2" align="right" valign="middle">&nbsp;</td>
    <td align="right" valign="middle">&nbsp;</td>
  </tr>
  <tr>
    <td valign="middle">&nbsp;</td>
    <td colspan="2" align="right" valign="middle">'.$strings["subtotal"].'</td>
    <td align="right" valign="middle">'.$strings['currency_symbol'].''.$_POST["totalPrice"].'</td>
  </tr>
  <tr>
    <td valign="middle">&nbsp;</td>
    <td colspan="2" align="right" valign="middle">'.$strings["vat"].'</td>
    <td align="right" valign="middle">'.$strings['currency_symbol'].''.($_POST["totalPrice"]*$_POST["vat"]/100).'</td>
  </tr>
  <tr>
    <td valign="middle">&nbsp;</td>
    <td colspan="2" align="right" valign="middle">'.$strings["shipping"].'</td>
    <td align="right" valign="middle">'.$strings['currency_symbol'].''.$_POST["totalShipping"].'</td>
  </tr>
  <tr>
    <td valign="middle">&nbsp;</td>
    <td colspan="2" align="right" valign="middle"><h3>'.$strings["total"].'</h3></td>
    <td align="right" valign="middle"><h3>('.$strings['currency'].') '.$strings['currency_symbol'].''.($_POST["total"]+($_POST["totalPrice"]*$_POST["vat"]/100)).'</h3></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="40">&nbsp;</td>
  </tr>
  <tr>
    <td class="notes"><strong>'.$strings["notes"].'</strong><br />
    '.$_POST["message"].'</td>
  </tr>
</table>
</body>';


	if(@mail($strings['mailSeller'], $strings['subject'], $email, "From: ".$strings['mailBuyer']."\r\nContent-type: text/html\r\n")){
		@mail($strings['mailBuyer'], $strings['subjectForBuyer'], $email, "From: ".$strings['mailSeller']."\r\nContent-type: text/html\r\n");
		echo "success";
	}else{
		echo "error";
	}
}

function saveNumberOrder(){

	$fileController = @fopen("number_order_form.txt","r+");
	
	if($fileController == false){
		$fileController = fopen("number_order_form.txt","w+");
		$counter = 1;
		fputs($fileController,$counter);
		fclose($fileController);
	}else{
		while(!feof($fileController)){ 

   		$buffer = fgets($fileController); 
    		$counter = (int)($buffer) + 1;
		} 
		
		rewind($fileController); 
		fputs($fileController,$counter);
			
		fclose($fileController);
		
	}
	
	return $counter;
}
?>