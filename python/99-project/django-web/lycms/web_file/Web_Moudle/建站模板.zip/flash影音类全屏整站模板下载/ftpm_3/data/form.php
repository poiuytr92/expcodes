<?php

$action = $_POST['accion'];
$security_code = 'e98jkNh09qXl'; 					//Do not change this, this is to avoid ilegal use

$subject = "New contact from www.yourdomain.com";	//Email subject
$to = 'email@yourdomain.com';						//Email to recieve message
$name = $_POST['name_input'];						//Name input from Contact Form
$mailfrom = $_POST['email_input'];					//Email input from Contact Form
$message = $_POST['message_input'];					//Message input from Contact Form


$msg .= "$name, sent the follow message:\n\n";
$msg .= $message."\n\n";
$msg .= "____________________________________\n";
$msg .= "Email: $mailfrom\n";

if ($action == $security_code){ 
	if(@mail($to, $subject, $msg, "From: $mailfrom")){		
		?>1<?php
	} else {
		?>0<?php
	} 
}
?>