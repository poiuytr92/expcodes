$(document).ready(function(){

	$(".topbar-btn").click(function(){
	  $(".topbar").slideToggle("slow");
	  $(this).toggleClass("active");
	});

});


