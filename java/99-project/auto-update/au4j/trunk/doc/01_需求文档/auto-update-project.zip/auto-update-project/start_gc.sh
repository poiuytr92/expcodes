#!/bin/bash
# ws-collector 

export lib0=./lib

PID=`ps -ef|grep 'Dws-collector '|grep -v grep|awk '{print $2}'`
if [ -z $PID ];then
    java -Dws-collector  -Xms64m -Xmx512m -Dcom.sun.management.jmxremote.port=9004 -Dcom.sun.management.jmxremote.ssl="false" -Dcom.sun.management.jmxremote.authenticate="false" -verbose:gc -Xloggc:gc.log   -cp $lib0/ws-collector.jar:$lib0/dom4j-1.6.1.jar:$lib0/cxf-rt-transports-http-3.0.1.jar:$lib0/slf4j-api-1.7.5.jar:$lib0/commons-dbutils-1.5.jar:$lib0/catt-pub-net.jar:$lib0/commons-compress-1.8.1.jar:$lib0/janino-2.7.8.jar:$lib0/catt-pub-db.jar:$lib0/jaxb-core-2.1.14.jar:$lib0/logback-access-1.0.13.jar:$lib0/logback-core-1.0.13.jar:$lib0/jdom-1.1.jar:$lib0/wsc-integrity-analyzer.jar:$lib0/ws-xml-parser.jar:$lib0/stax2-api-3.1.4.jar:$lib0/catt-pub-conf.jar:$lib0/catt-jackson-all.jar:$lib0/xmlbeans-2.6.0.jar:$lib0/proxool-cglib-0.9.1.jar:$lib0/cxf-rt-frontend-jaxws-3.0.1.jar:$lib0/proxool-0.9.1.jar:$lib0/cxf-rt-databinding-jaxb-3.0.1.jar:$lib0/asm-3.3.1.jar:$lib0/commons-lang3-3.3.jar:$lib0/catt-utils.jar:$lib0/sysself-waitmonitor.jar:$lib0/commons-httpclient-3.1.jar:$lib0/service-com-1.0.jar:$lib0/jabref-2.9.2.jar:$lib0/cxf-rt-wsdl-3.0.1.jar:$lib0/soapui-xmlbeans-1.7.jar:$lib0/commons-logging-1.1.3.jar:$lib0/cxf-core-3.0.1.jar:$lib0/activemq-all-5.4.2.jar:$lib0/commons-codec-1.8.jar:$lib0/commons-beanutils-1.8.3.jar:$lib0/cxf-rt-frontend-simple-3.0.1.jar:$lib0/commons-io-2.4.jar:$lib0/mysql-5.1.29.jar:$lib0/logback-classic-1.0.13.jar:$lib0/soapui-1.7.1.jar:$lib0/beauty-eye-3.4.jar:$lib0/wsdl4j-1.6.2.jar:$lib0/commons-net-3.3.jar:$lib0/ws-xml-constructor.jar:$lib0/commons-compiler-2.7.8.jar:$lib0/jsch-0.1.29.jar:$lib0/stax-api-1.0.1.jar:$lib0/cxf-rt-bindings-soap-3.0.1.jar:$lib0/xmlschema-core-2.1.0.jar:$lib0/wsdl4j-1.6.3.jar:$lib0/woodstox-core-asl-4.4.0.jar: com.catt.zhwg.ws.collect.conf.Main  >/dev/null 2>err.log @{run_in_background}@
else
    echo "The program ws-collector  has been running.Please stop it firstly."
fi
