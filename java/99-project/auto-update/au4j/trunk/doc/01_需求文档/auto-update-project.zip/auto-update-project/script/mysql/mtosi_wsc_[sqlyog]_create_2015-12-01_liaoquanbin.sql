/*
SQLyog Ultimate v11.25 (64 bit)
MySQL - 5.6.14 : Database - mtosi_wsc
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `ccic_op_exe_log` */

DROP TABLE IF EXISTS `ccic_op_exe_log`;

CREATE TABLE `ccic_op_exe_log` (
  `AUTO_ID` int(11) NOT NULL,
  `INTERFACE_ID` int(11) NOT NULL,
  `INTERFACE_CATG` varchar(64) NOT NULL,
  `INTERFACE_NAME` varchar(64) NOT NULL,
  `REQUEST_TIME` varchar(50) DEFAULT NULL,
  `ACCEPT_TIME` varchar(50) DEFAULT NULL,
  `FINISH_TIME` varchar(50) DEFAULT NULL,
  `REMARK` varchar(255) DEFAULT NULL,
  `PARA_LIST_STR` text,
  `EMS_NAME` varchar(150) DEFAULT NULL,
  `OP_FLAG` smallint(6) NOT NULL,
  PRIMARY KEY (`AUTO_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_crossconnection` */

DROP TABLE IF EXISTS `t_mt_crossconnection`;

CREATE TABLE `t_mt_crossconnection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `ems_id` int(11) DEFAULT NULL,
  `managedElementName` varchar(255) DEFAULT NULL,
  `isActive` varchar(64) DEFAULT NULL,
  `direction` varchar(64) DEFAULT NULL,
  `ccType` varchar(64) DEFAULT NULL,
  `aEndName` varchar(511) DEFAULT NULL,
  `zEndName` varchar(511) DEFAULT NULL,
  `connectionId` varchar(64) DEFAULT NULL,
  `routeActualState` varchar(64) DEFAULT NULL,
  `routeAdminState` varchar(64) DEFAULT NULL,
  `isRouteExclusive` varchar(64) DEFAULT NULL,
  `routeId` varchar(64) DEFAULT NULL,
  `isRouteIntended` varchar(64) DEFAULT NULL,
  `isRouteInUseBy` varchar(64) DEFAULT NULL,
  `vendorExtensions` varchar(2047) DEFAULT NULL,
  `SGUID` decimal(15,0) DEFAULT NULL,
  `I_VER` int(11) DEFAULT NULL,
  `D_INSERT_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_task_id` (`task_id`),
  KEY `idx_managedElementName` (`managedElementName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_ctp` */

DROP TABLE IF EXISTS `t_mt_ctp`;

CREATE TABLE `t_mt_ctp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ems_id` int(11) DEFAULT NULL,
  `task_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `userLabel` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `connectionState` varchar(255) DEFAULT NULL,
  `tpMappingMode` varchar(255) DEFAULT NULL,
  `direction` varchar(255) DEFAULT NULL,
  `tpProtectionAssociation` varchar(255) DEFAULT NULL,
  `edgePoint` varchar(255) DEFAULT NULL,
  `discoveredName` varchar(255) DEFAULT NULL,
  `namingOs` varchar(255) DEFAULT NULL,
  `aliasNameList` varchar(255) DEFAULT NULL,
  `vendorExtensions` varchar(2047) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `networkAccessDomain` varchar(255) DEFAULT NULL,
  `meiAttributes` varchar(255) DEFAULT NULL,
  `resourceState` varchar(255) DEFAULT NULL,
  `isEdgePoint` varchar(255) DEFAULT NULL,
  `isEquipmentProtected` varchar(255) DEFAULT NULL,
  `egressTmdState` varchar(255) DEFAULT NULL,
  `ingressTmdState` varchar(255) DEFAULT NULL,
  `ingressTmdRef` varchar(255) DEFAULT NULL,
  `egressTmdRef` varchar(255) DEFAULT NULL,
  `transmissionParametersList` text,
  `managedElementName` varchar(255) DEFAULT NULL,
  `tpName` varchar(255) DEFAULT NULL,
  `_neName` varchar(150) DEFAULT NULL,
  `_nativeEMSName` varchar(255) DEFAULT NULL,
  `_ingressTrafficDescriptorName` varchar(255) DEFAULT NULL,
  `_egressTrafficDescriptorName` varchar(255) DEFAULT NULL,
  `_type` varchar(4000) DEFAULT NULL,
  `_transmissionParams` varchar(511) DEFAULT NULL,
  `_additionalInfo` varchar(511) DEFAULT NULL,
  `D_INSERT_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_task_id` (`task_id`),
  KEY `idx_managedElementName` (`managedElementName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_ems` */

DROP TABLE IF EXISTS `t_mt_ems`;

CREATE TABLE `t_mt_ems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `userLabel` varchar(255) DEFAULT NULL,
  `discoveredName` varchar(255) DEFAULT NULL,
  `namingOs` varchar(255) DEFAULT NULL,
  `aliasNameList` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `vendorExtensions` varchar(2047) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `networkAccessDomain` varchar(255) DEFAULT NULL,
  `meiAttributes` varchar(255) DEFAULT NULL,
  `resourceState` varchar(255) DEFAULT NULL,
  `softwareVersion` varchar(255) DEFAULT NULL,
  `productName` varchar(255) DEFAULT NULL,
  `manufacturer` varchar(255) DEFAULT NULL,
  `resourceFulfillmentState` varchar(255) DEFAULT NULL,
  `isSubordinateOs` varchar(255) DEFAULT NULL,
  `asapRef` varchar(511) DEFAULT NULL,
  `SGUID` decimal(15,0) DEFAULT NULL,
  `I_VER` int(11) DEFAULT NULL,
  `D_INSERT_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_eprotectiongroup` */

DROP TABLE IF EXISTS `t_mt_eprotectiongroup`;

CREATE TABLE `t_mt_eprotectiongroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `ems_id` int(11) DEFAULT NULL,
  `managedElementName` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `userLabel` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `discoveredName` varchar(255) DEFAULT NULL,
  `namingOs` varchar(255) DEFAULT NULL,
  `aliasNameList` varchar(255) DEFAULT NULL,
  `vendorExtensions` varchar(2047) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `networkAccessDomain` varchar(255) DEFAULT NULL,
  `meiAttributes` varchar(255) DEFAULT NULL,
  `resourceState` varchar(255) DEFAULT NULL,
  `eProtectionGroupType` varchar(64) DEFAULT NULL,
  `protectionSchemeState` varchar(64) DEFAULT NULL,
  `reversionMode` varchar(64) DEFAULT NULL,
  `parameterList` varchar(255) DEFAULT NULL,
  `protectedEquipmentRefList` varchar(255) DEFAULT NULL,
  `protectingEquipmentRefList` varchar(255) DEFAULT NULL,
  `SGUID` decimal(15,0) DEFAULT NULL,
  `I_VER` int(11) DEFAULT NULL,
  `I_INSERT_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_task_id` (`task_id`),
  KEY `idx_managedElementName` (`managedElementName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_equipment` */

DROP TABLE IF EXISTS `t_mt_equipment`;

CREATE TABLE `t_mt_equipment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ems_id` int(11) DEFAULT NULL,
  `task_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `userLabel` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `expectedEquipmentObjectType` varchar(255) DEFAULT NULL,
  `installedEquipmentObjectType` varchar(255) DEFAULT NULL,
  `installedPartNumber` varchar(255) DEFAULT NULL,
  `installedVersion` varchar(255) DEFAULT NULL,
  `installedSerialNumber` varchar(255) DEFAULT NULL,
  `discoveredName` varchar(255) DEFAULT NULL,
  `namingOs` varchar(255) DEFAULT NULL,
  `aliasNameList` varchar(255) DEFAULT NULL,
  `vendorExtensions` varchar(2047) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `networkAccessDomain` varchar(255) DEFAULT NULL,
  `meiAttributes` varchar(255) DEFAULT NULL,
  `resourceState` varchar(255) DEFAULT NULL,
  `isReportingAlarms` varchar(255) DEFAULT NULL,
  `resourceFulfillmentState` varchar(255) DEFAULT NULL,
  `manufacturer` varchar(255) DEFAULT NULL,
  `protectionRole` varchar(255) DEFAULT NULL,
  `protectionSchemeState` varchar(255) DEFAULT NULL,
  `manufactureDate` varchar(255) DEFAULT NULL,
  `asapRef` varchar(255) DEFAULT NULL,
  `managedElementName` varchar(255) DEFAULT NULL,
  `_nativeEMSName` varchar(255) DEFAULT NULL,
  `_alarmReportingIndicator` varchar(255) DEFAULT NULL,
  `_serviceState` varchar(255) DEFAULT NULL,
  `_egressTrafficDescriptorName` varchar(255) DEFAULT NULL,
  `_additionalInfo` varchar(511) DEFAULT NULL,
  `D_INSERT_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_task_id` (`task_id`),
  KEY `idx_managedElementName` (`managedElementName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_equipmentholder` */

DROP TABLE IF EXISTS `t_mt_equipmentholder`;

CREATE TABLE `t_mt_equipmentholder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ems_id` int(11) DEFAULT NULL,
  `task_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `userLabel` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `holderType` varchar(255) DEFAULT NULL,
  `expectedOrInstalledEquipmentRef` varchar(255) DEFAULT NULL,
  `acceptableEquipmentTypeList` varchar(4095) DEFAULT NULL,
  `holderState` varchar(255) DEFAULT NULL,
  `asapRef` varchar(255) DEFAULT NULL,
  `discoveredName` varchar(255) DEFAULT NULL,
  `namingOs` varchar(255) DEFAULT NULL,
  `aliasNameList` varchar(255) DEFAULT NULL,
  `vendorExtensions` varchar(2047) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `networkAccessDomain` varchar(255) DEFAULT NULL,
  `meiAttributes` varchar(255) DEFAULT NULL,
  `resourceState` varchar(255) DEFAULT NULL,
  `isReportingAlarms` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `manufacturer` varchar(255) DEFAULT NULL,
  `manufactureDate` varchar(255) DEFAULT NULL,
  `managedElementName` varchar(255) DEFAULT NULL,
  `_nativeEMSName` varchar(255) DEFAULT NULL,
  `_alarmReportingIndicator` varchar(255) DEFAULT NULL,
  `_additionalInfo` varchar(511) DEFAULT NULL,
  `_expectedOrInstalledEquipment` varchar(255) DEFAULT NULL,
  `D_INSERT_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `SGUID` decimal(15,0) DEFAULT NULL,
  `I_VER` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_task_id` (`task_id`),
  KEY `idx_managedElementName` (`managedElementName`),
  KEY `idx_holderType` (`holderType`),
  KEY `idx_name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_fault` */

DROP TABLE IF EXISTS `t_mt_fault`;

CREATE TABLE `t_mt_fault` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ems_id` int(11) DEFAULT NULL,
  `task_id` int(11) DEFAULT NULL,
  `faultwsif` varchar(64) DEFAULT NULL,
  `faultcode` varchar(128) DEFAULT NULL,
  `faultstring` text,
  `detail` varchar(2048) DEFAULT NULL,
  `D_INSERT_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_managedelement` */

DROP TABLE IF EXISTS `t_mt_managedelement`;

CREATE TABLE `t_mt_managedelement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ems_id` int(11) DEFAULT NULL,
  `task_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `userLabel` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `productName` varchar(255) DEFAULT NULL,
  `communicationState` varchar(255) DEFAULT NULL,
  `supportedConnectionLayerRateList` varchar(2047) DEFAULT NULL,
  `discoveredName` varchar(255) DEFAULT NULL,
  `namingOs` varchar(255) DEFAULT NULL,
  `vendorExtensions` varchar(2047) DEFAULT NULL,
  `aliasNameList` varchar(255) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `resourceState` varchar(255) DEFAULT NULL,
  `manufacturer` varchar(255) DEFAULT NULL,
  `manufactureDate` varchar(255) DEFAULT NULL,
  `softwareVersion` varchar(255) DEFAULT NULL,
  `isInSyncState` varchar(255) DEFAULT NULL,
  `asapRef` varchar(255) DEFAULT NULL,
  `_subnetName` varchar(250) DEFAULT NULL,
  `_nativeEMSName` varchar(255) DEFAULT NULL,
  `_version` varchar(255) DEFAULT NULL,
  `_emsInSyncState` varchar(255) DEFAULT NULL,
  `_supportedRates` varchar(255) DEFAULT NULL,
  `_additionalInfo` varchar(511) DEFAULT NULL,
  `D_INSERT_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `networkAccessDomain` varchar(255) DEFAULT NULL,
  `meiAttributes` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_task_id` (`task_id`),
  KEY `idx_name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_nt_alarm_sync` */

DROP TABLE IF EXISTS `t_mt_nt_alarm_sync`;

CREATE TABLE `t_mt_nt_alarm_sync` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ems_id` int(11) DEFAULT NULL,
  `task_id` int(11) DEFAULT NULL,
  `notificationId` varchar(255) DEFAULT NULL,
  `objectName` varchar(255) DEFAULT NULL,
  `objectType` varchar(255) DEFAULT NULL,
  `isClearable` varchar(255) DEFAULT NULL,
  `layerRate` varchar(255) DEFAULT NULL,
  `probableCause` varchar(511) DEFAULT NULL,
  `nativeProbableCause` varchar(255) DEFAULT NULL,
  `perceivedSeverity` varchar(255) DEFAULT NULL,
  `additionalText` varchar(511) DEFAULT NULL,
  `sourceTime` varchar(255) DEFAULT NULL,
  `vendorExtensions` varchar(2047) DEFAULT NULL,
  `osTime` varchar(255) DEFAULT NULL,
  `isEdgePointRelated` varchar(255) DEFAULT NULL,
  `aliasNameList` varchar(255) DEFAULT NULL,
  `affectedPtpRefList` varchar(255) DEFAULT NULL,
  `serviceAffecting` varchar(255) DEFAULT NULL,
  `rootCauseAlarmIndication` varchar(255) DEFAULT NULL,
  `acknowledgeIndication` varchar(255) DEFAULT NULL,
  `X733_EventType` varchar(255) DEFAULT NULL,
  `X733_SpecificProblems` varchar(255) DEFAULT NULL,
  `X733_BackedUpStatus` varchar(255) DEFAULT NULL,
  `X733_BackUpObjectRef` varchar(255) DEFAULT NULL,
  `X733_TrendIndication` varchar(255) DEFAULT NULL,
  `X733_CorrelatedNotificationList` varchar(255) DEFAULT NULL,
  `X733_MonitoredAttributeList` varchar(255) DEFAULT NULL,
  `X733_ProposedRepairActionList` varchar(255) DEFAULT NULL,
  `X733_AdditionalInformation` varchar(255) DEFAULT NULL,
  `_nativeEMSName` varchar(255) DEFAULT NULL,
  `_emsTime` varchar(255) DEFAULT NULL,
  `_neTime` varchar(255) DEFAULT NULL,
  `_probableCauseQualifier` varchar(511) DEFAULT NULL,
  `_affectedTPList` varchar(511) DEFAULT NULL,
  `_additionalInfo` varchar(511) DEFAULT NULL,
  `_unit` varchar(255) DEFAULT NULL,
  `_X733EventType` varchar(255) DEFAULT NULL,
  `_X733SpecificProblems` varchar(255) DEFAULT NULL,
  `_X733BackedUpStatus` varchar(255) DEFAULT NULL,
  `_X733BackUpObject` varchar(255) DEFAULT NULL,
  `_X733TrendIndication` varchar(255) DEFAULT NULL,
  `_X733CorrelatedNotifications` varchar(255) DEFAULT NULL,
  `_X733MonitoredAttributes` varchar(255) DEFAULT NULL,
  `_X733ProposedRepairActions` varchar(255) DEFAULT NULL,
  `_X733AdditionalInfo` varchar(255) DEFAULT NULL,
  `D_INSERT_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `D_OS_TIME` datetime DEFAULT NULL,
  `D_SOURCE_TIME` datetime DEFAULT NULL,
  `AlarmSerialNo` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_protectiongroup` */

DROP TABLE IF EXISTS `t_mt_protectiongroup`;

CREATE TABLE `t_mt_protectiongroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `ems_id` int(11) DEFAULT NULL,
  `managedElementName` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `userLabel` varchar(255) DEFAULT NULL,
  `nativeEMSName` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `discoveredName` varchar(255) DEFAULT NULL,
  `namingOs` varchar(255) DEFAULT NULL,
  `aliasNameList` varchar(255) DEFAULT NULL,
  `vendorExtensions` varchar(2047) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `networkAccessDomain` varchar(255) DEFAULT NULL,
  `meiAttributes` varchar(255) DEFAULT NULL,
  `resourceState` varchar(255) DEFAULT NULL,
  `protectionGroupType` varchar(64) DEFAULT NULL,
  `protectionSchemeState` varchar(64) DEFAULT NULL,
  `reversionMode` varchar(64) DEFAULT NULL,
  `layerRate` varchar(64) DEFAULT NULL,
  `parameterList` varchar(512) DEFAULT NULL,
  `protectionRelatedTpRefList` varchar(512) DEFAULT NULL,
  `apsProtocolType` varchar(64) DEFAULT NULL,
  `asapRef` varchar(512) DEFAULT NULL,
  `_rate` int(11) DEFAULT NULL,
  `_additionalInfo` varchar(255) DEFAULT NULL,
  `_pgpParameters` varchar(511) DEFAULT NULL,
  `_seq` int(11) DEFAULT NULL,
  `D_INSERT_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_task_id` (`task_id`),
  KEY `idx_managedElementName` (`managedElementName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_redo` */

DROP TABLE IF EXISTS `t_mt_redo`;

CREATE TABLE `t_mt_redo` (
  `i_id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `ems_id` int(11) DEFAULT NULL,
  `s_method` varchar(256) DEFAULT NULL,
  `s_redo_params` text,
  `i_redone` int(11) DEFAULT NULL,
  PRIMARY KEY (`i_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_snc_tp` */

DROP TABLE IF EXISTS `t_mt_snc_tp`;

CREATE TABLE `t_mt_snc_tp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tp_seq` int(11) DEFAULT NULL,
  `route_seq` int(11) DEFAULT NULL,
  `ems_id` int(11) DEFAULT NULL,
  `task_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `tpMappingMode` varchar(255) DEFAULT NULL,
  `tpRef` varchar(255) DEFAULT NULL,
  `transmissionParametersList` text,
  `ingressTmdRef` varchar(255) DEFAULT NULL,
  `egressTmdRef` varchar(255) DEFAULT NULL,
  `snc_name` varchar(255) DEFAULT NULL,
  `subnetName` varchar(255) DEFAULT NULL,
  `_snc_id` varchar(255) DEFAULT NULL,
  `_tp_end_type` varchar(255) DEFAULT NULL,
  `_tpName` varchar(255) DEFAULT NULL,
  `_transmissionParams` varchar(511) DEFAULT NULL,
  `_ingressTrafficDescriptorName` varchar(255) DEFAULT NULL,
  `_egressTrafficDescriptorName` varchar(255) DEFAULT NULL,
  `D_INSERT_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `SGUID` decimal(15,0) DEFAULT NULL,
  `I_VER` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_task_id` (`task_id`),
  KEY `idx_name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_sncroute` */

DROP TABLE IF EXISTS `t_mt_sncroute`;

CREATE TABLE `t_mt_sncroute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `routeSeq` int(11) DEFAULT NULL,
  `ems_id` int(11) DEFAULT NULL,
  `task_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `direction` varchar(255) DEFAULT NULL,
  `ccType` varchar(255) DEFAULT NULL,
  `isActive` varchar(255) DEFAULT NULL,
  `isFixed` varchar(255) DEFAULT NULL,
  `aEndRefList` varchar(2047) DEFAULT NULL,
  `zEndRefList` varchar(2047) DEFAULT NULL,
  `connectionId` varchar(255) DEFAULT NULL,
  `routeActualState` varchar(255) DEFAULT NULL,
  `routeAdminState` varchar(255) DEFAULT NULL,
  `isRouteExclusive` varchar(255) DEFAULT NULL,
  `routeId` varchar(255) DEFAULT NULL,
  `isRouteIntended` varchar(255) DEFAULT NULL,
  `isRouteInUseBy` varchar(255) DEFAULT NULL,
  `vendorExtensions` varchar(2047) DEFAULT NULL,
  `snc_name` varchar(255) DEFAULT NULL,
  `_active` varchar(255) DEFAULT NULL,
  `_aEndName` varchar(255) DEFAULT NULL,
  `_zEndName` varchar(255) DEFAULT NULL,
  `_additionalInfo` varchar(511) DEFAULT NULL,
  `D_INSERT_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `SGUID` decimal(15,0) DEFAULT NULL,
  `I_VER` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_task_id` (`task_id`),
  KEY `idx_name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_state_filter` */

DROP TABLE IF EXISTS `t_mt_state_filter`;

CREATE TABLE `t_mt_state_filter` (
  `i_id` int(11) NOT NULL AUTO_INCREMENT,
  `s_method` varchar(64) DEFAULT NULL,
  `s_ref_name` varchar(256) DEFAULT NULL,
  `s_category` varchar(64) DEFAULT NULL,
  `i_enable` int(11) NOT NULL DEFAULT '0',
  `s_remark` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`i_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_statistics` */

DROP TABLE IF EXISTS `t_mt_statistics`;

CREATE TABLE `t_mt_statistics` (
  `i_id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `d_insert_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `s_cmd` varchar(64) DEFAULT NULL,
  `i_ems` int(11) DEFAULT NULL,
  `i_me` int(11) DEFAULT NULL,
  `i_eq` int(11) DEFAULT NULL,
  `i_eh` int(11) DEFAULT NULL,
  `i_ptp` int(11) DEFAULT NULL,
  `i_ptp_tp` int(11) DEFAULT NULL,
  `i_ctp` int(11) DEFAULT NULL,
  `i_ctp_tp` int(11) DEFAULT NULL,
  `i_timeslot` int(11) DEFAULT NULL,
  `i_ftp` int(11) DEFAULT NULL,
  `i_ftp_tp` int(11) DEFAULT NULL,
  `i_cc` int(11) DEFAULT NULL,
  `i_epg` int(11) DEFAULT NULL,
  `i_pg` int(11) DEFAULT NULL,
  `i_alarm` int(11) DEFAULT NULL,
  `i_sn` int(11) DEFAULT NULL,
  `i_topo_link` int(11) DEFAULT NULL,
  `i_snc` int(11) DEFAULT NULL,
  `i_snc_tp` int(11) DEFAULT NULL,
  `i_route` int(11) DEFAULT NULL,
  `i_topo_node` int(11) DEFAULT NULL,
  PRIMARY KEY (`i_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_statistics_redundance` */

DROP TABLE IF EXISTS `t_mt_statistics_redundance`;

CREATE TABLE `t_mt_statistics_redundance` (
  `i_id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `d_insert_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `s_cmd` varchar(64) DEFAULT NULL,
  `i_ems` int(11) DEFAULT NULL,
  `i_me` int(11) DEFAULT NULL,
  `i_eq` int(11) DEFAULT NULL,
  `i_eh` int(11) DEFAULT NULL,
  `i_ptp` int(11) DEFAULT NULL,
  `i_ptp_tp` int(11) DEFAULT NULL,
  `i_ctp` int(11) DEFAULT NULL,
  `i_ctp_tp` int(11) DEFAULT NULL,
  `i_timeslot` int(11) DEFAULT NULL,
  `i_ftp` int(11) DEFAULT NULL,
  `i_ftp_tp` int(11) DEFAULT NULL,
  `i_cc` int(11) DEFAULT NULL,
  `i_epg` int(11) DEFAULT NULL,
  `i_pg` int(11) DEFAULT NULL,
  `i_alarm` int(11) DEFAULT NULL,
  `i_sn` int(11) DEFAULT NULL,
  `i_topo_link` int(11) DEFAULT NULL,
  `i_snc` int(11) DEFAULT NULL,
  `i_snc_tp` int(11) DEFAULT NULL,
  `i_route` int(11) DEFAULT NULL,
  `i_topo_node` int(11) DEFAULT NULL,
  PRIMARY KEY (`i_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_statistics_wsif` */

DROP TABLE IF EXISTS `t_mt_statistics_wsif`;

CREATE TABLE `t_mt_statistics_wsif` (
  `i_id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `s_cmd` varchar(64) DEFAULT NULL,
  `d_st` timestamp NULL DEFAULT NULL,
  `d_et` timestamp NULL DEFAULT NULL,
  `s_exec_status` varchar(255) DEFAULT NULL,
  `d_ems_st` timestamp NULL DEFAULT NULL,
  `d_ems_et` timestamp NULL DEFAULT NULL,
  `s_ems_ok` varchar(8) DEFAULT NULL,
  `d_me_st` timestamp NULL DEFAULT NULL,
  `d_me_et` timestamp NULL DEFAULT NULL,
  `s_me_ok` varchar(8) DEFAULT NULL,
  `d_eoh_st` timestamp NULL DEFAULT NULL,
  `d_eoh_et` timestamp NULL DEFAULT NULL,
  `s_eoh_ok` varchar(8) DEFAULT NULL,
  `d_ptp_st` timestamp NULL DEFAULT NULL,
  `d_ptp_et` timestamp NULL DEFAULT NULL,
  `s_ptp_ok` varchar(8) DEFAULT NULL,
  `d_ptp_tp_st` timestamp NULL DEFAULT NULL,
  `d_ptp_tp_et` timestamp NULL DEFAULT NULL,
  `s_ptp_tp_ok` varchar(8) DEFAULT NULL,
  `d_ctp_st` timestamp NULL DEFAULT NULL,
  `d_ctp_et` timestamp NULL DEFAULT NULL,
  `s_ctp_ok` varchar(8) DEFAULT NULL,
  `d_ctp_tp_st` timestamp NULL DEFAULT NULL,
  `d_ctp_tp_et` timestamp NULL DEFAULT NULL,
  `s_ctp_tp_ok` varchar(8) DEFAULT NULL,
  `d_timeslot_st` timestamp NULL DEFAULT NULL,
  `d_timeslot_et` timestamp NULL DEFAULT NULL,
  `s_timeslot_ok` varchar(8) DEFAULT NULL,
  `d_ftp_st` timestamp NULL DEFAULT NULL,
  `d_ftp_et` timestamp NULL DEFAULT NULL,
  `s_ftp_ok` varchar(8) DEFAULT NULL,
  `d_ftp_tp_st` timestamp NULL DEFAULT NULL,
  `d_ftp_tp_et` timestamp NULL DEFAULT NULL,
  `s_ftp_tp_ok` varchar(8) DEFAULT NULL,
  `d_cc_st` timestamp NULL DEFAULT NULL,
  `d_cc_et` timestamp NULL DEFAULT NULL,
  `s_cc_ok` varchar(8) DEFAULT NULL,
  `d_epg_st` timestamp NULL DEFAULT NULL,
  `d_epg_et` timestamp NULL DEFAULT NULL,
  `s_epg_ok` varchar(8) DEFAULT NULL,
  `d_pg_st` timestamp NULL DEFAULT NULL,
  `d_pg_et` timestamp NULL DEFAULT NULL,
  `s_pg_ok` varchar(8) DEFAULT NULL,
  `d_alarm_st` timestamp NULL DEFAULT NULL,
  `d_alarm_et` timestamp NULL DEFAULT NULL,
  `s_alarm_ok` varchar(8) DEFAULT NULL,
  `d_sn_st` timestamp NULL DEFAULT NULL,
  `d_sn_et` timestamp NULL DEFAULT NULL,
  `s_sn_ok` varchar(8) DEFAULT NULL,
  `d_topolink_st` timestamp NULL DEFAULT NULL,
  `d_topolink_et` timestamp NULL DEFAULT NULL,
  `s_topolink_ok` varchar(8) DEFAULT NULL,
  `d_snc_st` timestamp NULL DEFAULT NULL,
  `d_snc_et` timestamp NULL DEFAULT NULL,
  `s_snc_ok` varchar(8) DEFAULT NULL,
  `d_route_st` timestamp NULL DEFAULT NULL,
  `d_route_et` timestamp NULL DEFAULT NULL,
  `s_route_ok` varchar(8) DEFAULT NULL,
  `d_toponode_st` timestamp NULL DEFAULT NULL,
  `d_toponode_et` timestamp NULL DEFAULT NULL,
  `s_toponode_ok` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`i_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_subnetworkconnection` */

DROP TABLE IF EXISTS `t_mt_subnetworkconnection`;

CREATE TABLE `t_mt_subnetworkconnection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `route_seq` int(11) DEFAULT NULL,
  `ems_id` int(11) DEFAULT NULL,
  `task_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `userLabel` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `sncState` varchar(255) DEFAULT NULL,
  `direction` varchar(255) DEFAULT NULL,
  `staticProtectionLevel` varchar(255) DEFAULT NULL,
  `sncType` varchar(255) DEFAULT NULL,
  `rerouteAllowed` varchar(255) DEFAULT NULL,
  `networkRouted` varchar(255) DEFAULT NULL,
  `discoveredName` varchar(255) DEFAULT NULL,
  `namingOs` varchar(255) DEFAULT NULL,
  `aliasNameList` varchar(255) DEFAULT NULL,
  `vendorExtensions` text,
  `source` varchar(255) DEFAULT NULL,
  `resourceState` varchar(255) DEFAULT NULL,
  `layerRate` varchar(255) DEFAULT NULL,
  `isFixed` varchar(255) DEFAULT NULL,
  `asapRef` varchar(255) DEFAULT NULL,
  `correlationIdentifier` varchar(255) DEFAULT NULL,
  `networkReroute` varchar(255) DEFAULT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `revertive` varchar(255) DEFAULT NULL,
  `isBundledSnc` varchar(255) DEFAULT NULL,
  `callId` varchar(255) DEFAULT NULL,
  `callName` varchar(255) DEFAULT NULL,
  `connectionId` varchar(255) DEFAULT NULL,
  `connectionSetUpType` varchar(255) DEFAULT NULL,
  `connectionState` varchar(255) DEFAULT NULL,
  `maximumCost` varchar(255) DEFAULT NULL,
  `isMustRemoveGtpList` varchar(255) DEFAULT NULL,
  `protectionEffort` varchar(255) DEFAULT NULL,
  `routeGroupLabel` varchar(255) DEFAULT NULL,
  `routingConstraintEffort` varchar(255) DEFAULT NULL,
  `supportedConnectionName` varchar(255) DEFAULT NULL,
  `supportingSncList` varchar(255) DEFAULT NULL,
  `aEndPointsRole` varchar(255) DEFAULT NULL,
  `zEndPointsRole` varchar(255) DEFAULT NULL,
  `isReportingAlarms` varchar(255) DEFAULT NULL,
  `networkAccessDomain` varchar(255) DEFAULT NULL,
  `meiAttributes` varchar(255) DEFAULT NULL,
  `_nativeEMSName` varchar(255) DEFAULT NULL,
  `_additionalInfo` varchar(511) DEFAULT NULL,
  `_rate` varchar(255) DEFAULT NULL,
  `subnetName` varchar(256) DEFAULT NULL,
  `D_INSERT_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_task_id` (`task_id`),
  KEY `idx_name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_subnetworks` */

DROP TABLE IF EXISTS `t_mt_subnetworks`;

CREATE TABLE `t_mt_subnetworks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `ems_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `userLabel` varchar(255) DEFAULT NULL,
  `discoveredName` varchar(255) DEFAULT NULL,
  `namingOs` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `aliasNameList` varchar(255) DEFAULT NULL,
  `vendorExtensions` varchar(2047) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `networkAccessDomain` varchar(255) DEFAULT NULL,
  `meiAttributes` varchar(255) DEFAULT NULL,
  `resourceState` varchar(255) DEFAULT NULL,
  `subnetworkType` varchar(255) DEFAULT NULL,
  `supportedRateList` varchar(512) DEFAULT NULL,
  `_nativeEMSName` varchar(255) DEFAULT NULL,
  `_additionalInfo` varchar(511) DEFAULT NULL,
  `_supportedRates` varchar(255) DEFAULT NULL,
  `D_INSERT_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_timeslot` */

DROP TABLE IF EXISTS `t_mt_timeslot`;

CREATE TABLE `t_mt_timeslot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `ems_id` int(11) DEFAULT NULL,
  `timeslot` varchar(256) DEFAULT NULL,
  `tpName` varchar(256) DEFAULT NULL,
  `D_INSERT_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_topologicallink` */

DROP TABLE IF EXISTS `t_mt_topologicallink`;

CREATE TABLE `t_mt_topologicallink` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ems_id` int(11) DEFAULT NULL,
  `task_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `userLabel` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `direction` varchar(255) DEFAULT NULL,
  `discoveredName` varchar(255) DEFAULT NULL,
  `namingOs` varchar(255) DEFAULT NULL,
  `aliasNameList` varchar(255) DEFAULT NULL,
  `vendorExtensions` varchar(2047) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `networkAccessDomain` varchar(255) DEFAULT NULL,
  `meiAttributes` varchar(255) DEFAULT NULL,
  `resourceState` varchar(255) DEFAULT NULL,
  `layerRate` varchar(255) DEFAULT NULL,
  `aEndTpRefList` varchar(255) DEFAULT NULL,
  `zEndTpRefList` varchar(255) DEFAULT NULL,
  `isReportingAlarms` varchar(255) DEFAULT NULL,
  `asapRef` varchar(255) DEFAULT NULL,
  `subnetName` varchar(250) DEFAULT NULL,
  `_nativeEMSName` varchar(255) DEFAULT NULL,
  `_rate` varchar(255) DEFAULT NULL,
  `_aEndTP` varchar(255) DEFAULT NULL,
  `_zEndTP` varchar(255) DEFAULT NULL,
  `_additionalInfo` varchar(511) DEFAULT NULL,
  `D_INSERT_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `S_FILE_NAME` varchar(256) DEFAULT NULL,
  `S_UNZIP_FILE_NAME` varchar(256) DEFAULT NULL,
  `I_SOURCE_FILE` smallint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_task_id` (`task_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_toponode` */

DROP TABLE IF EXISTS `t_mt_toponode`;

CREATE TABLE `t_mt_toponode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `ems_id` int(11) DEFAULT NULL,
  `name` varchar(256) DEFAULT NULL,
  `userLabel` varchar(256) DEFAULT NULL,
  `aliasNameList` varchar(256) DEFAULT NULL,
  `type` varchar(256) DEFAULT NULL,
  `xPos` int(11) DEFAULT NULL,
  `yPos` int(11) DEFAULT NULL,
  `parent` varchar(256) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `vendorExtensions` varchar(2048) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_tp` */

DROP TABLE IF EXISTS `t_mt_tp`;

CREATE TABLE `t_mt_tp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ems_id` int(11) DEFAULT NULL,
  `task_id` int(11) DEFAULT NULL,
  `tpProtectionAssociation` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `userLabel` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `connectionState` varchar(255) DEFAULT NULL,
  `tpMappingMode` varchar(255) DEFAULT NULL,
  `direction` varchar(255) DEFAULT NULL,
  `discoveredName` varchar(255) DEFAULT NULL,
  `namingOs` varchar(255) DEFAULT NULL,
  `aliasNameList` varchar(255) DEFAULT NULL,
  `vendorExtensions` varchar(2047) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `networkAccessDomain` varchar(255) DEFAULT NULL,
  `meiAttributes` varchar(255) DEFAULT NULL,
  `resourceState` varchar(255) DEFAULT NULL,
  `isEdgePoint` varchar(255) DEFAULT NULL,
  `isEquipmentProtected` varchar(255) DEFAULT NULL,
  `egressTmdState` varchar(255) DEFAULT NULL,
  `ingressTmdState` varchar(255) DEFAULT NULL,
  `ingressTmdRef` varchar(255) DEFAULT NULL,
  `egressTmdRef` varchar(255) DEFAULT NULL,
  `transmissionParametersList` text,
  `managedElementName` varchar(255) DEFAULT NULL,
  `_transmissionParams` varchar(1024) DEFAULT NULL,
  `_edgePoint` varchar(255) DEFAULT NULL,
  `_additionalInfo` varchar(511) DEFAULT NULL,
  `_ingressTrafficDescriptorName` varchar(255) DEFAULT NULL,
  `_egressTrafficDescriptorName` varchar(255) DEFAULT NULL,
  `_type` varchar(255) DEFAULT NULL,
  `_nativeEMSName` varchar(255) DEFAULT NULL,
  `D_INSERT_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `i_tp_type` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_task_id` (`task_id`),
  KEY `idx_managedElementName` (`managedElementName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_tp2` */

DROP TABLE IF EXISTS `t_mt_tp2`;

CREATE TABLE `t_mt_tp2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ems_id` int(11) DEFAULT NULL,
  `task_id` int(11) DEFAULT NULL,
  `tpProtectionAssociation` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `userLabel` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `connectionState` varchar(255) DEFAULT NULL,
  `tpMappingMode` varchar(255) DEFAULT NULL,
  `direction` varchar(255) DEFAULT NULL,
  `discoveredName` varchar(255) DEFAULT NULL,
  `namingOs` varchar(255) DEFAULT NULL,
  `aliasNameList` varchar(255) DEFAULT NULL,
  `vendorExtensions` varchar(2047) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `networkAccessDomain` varchar(255) DEFAULT NULL,
  `meiAttributes` varchar(255) DEFAULT NULL,
  `resourceState` varchar(255) DEFAULT NULL,
  `isEdgePoint` varchar(255) DEFAULT NULL,
  `isEquipmentProtected` varchar(255) DEFAULT NULL,
  `egressTmdState` varchar(255) DEFAULT NULL,
  `ingressTmdState` varchar(255) DEFAULT NULL,
  `ingressTmdRef` varchar(255) DEFAULT NULL,
  `egressTmdRef` varchar(255) DEFAULT NULL,
  `transmissionParametersList` text,
  `managedElementName` varchar(255) DEFAULT NULL,
  `_transmissionParams` varchar(1024) DEFAULT NULL,
  `_edgePoint` varchar(255) DEFAULT NULL,
  `_additionalInfo` varchar(511) DEFAULT NULL,
  `_ingressTrafficDescriptorName` varchar(255) DEFAULT NULL,
  `_egressTrafficDescriptorName` varchar(255) DEFAULT NULL,
  `_type` varchar(255) DEFAULT NULL,
  `_nativeEMSName` varchar(255) DEFAULT NULL,
  `D_INSERT_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `i_tp_type` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_ws_exe_log` */

DROP TABLE IF EXISTS `t_mt_ws_exe_log`;

CREATE TABLE `t_mt_ws_exe_log` (
  `I_ID` int(11) NOT NULL AUTO_INCREMENT,
  `S_WS_URL` varchar(256) DEFAULT NULL,
  `S_WS_METHOD` varchar(256) DEFAULT NULL,
  `I_DELAY` int(11) DEFAULT NULL,
  `S_RESULT` mediumtext,
  `S_REMARK` varchar(4096) DEFAULT NULL,
  `S_REQUEST_STR` mediumtext,
  `S_RESPONSE_STR` mediumtext,
  `I_PRESS_ID` int(11) DEFAULT NULL,
  `I_INF_ID` int(11) DEFAULT NULL,
  `S_FTP_URI` varchar(256) DEFAULT NULL,
  `S_FILE_NAME` varchar(64) DEFAULT NULL,
  `S_COMPRESSION_TYPE` varchar(32) DEFAULT NULL,
  `S_STAFF_NAME` varchar(64) DEFAULT NULL,
  `I_STAFF_ID` smallint(11) DEFAULT NULL,
  `I_INF_STATE` smallint(1) DEFAULT NULL,
  `I_VAL_STATE` smallint(1) DEFAULT NULL,
  `I_CONFIRM_STATE` smallint(1) DEFAULT NULL,
  `I_EMS_ID` int(11) DEFAULT NULL,
  `L_INSERT_TIME` bigint(17) DEFAULT NULL,
  `L_REQUEST_TIME` bigint(17) DEFAULT NULL,
  `L_RESPONSE_TIME` bigint(17) DEFAULT NULL,
  `S_ZIP_FILE_NAME` varchar(64) DEFAULT NULL,
  `S_REQUEST_TIME` varchar(32) DEFAULT NULL,
  `S_RESPONSE_TIME` varchar(32) DEFAULT NULL,
  `D_REQUEST_TIME` datetime DEFAULT NULL,
  `D_RESPONSE_TIME` datetime DEFAULT NULL,
  `D_INSERT_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `I_TEST_TYPE` smallint(6) DEFAULT '1',
  `I_TESTCASE_ID` decimal(16,0) DEFAULT NULL,
  `S_TESTCASE_NAME` varchar(50) DEFAULT NULL,
  `I_ACCURACY_STATE` smallint(6) NOT NULL DEFAULT '0',
  `I_RESULT_STATE` smallint(6) NOT NULL DEFAULT '0',
  `S_ACCURACY_REMARK` varchar(256) DEFAULT NULL,
  `S_RESULT_REMARK` varchar(256) DEFAULT NULL,
  `I_DATA_AMOUNT` int(11) DEFAULT NULL,
  `I_ATTR_RATE` decimal(10,6) DEFAULT NULL,
  `I_ACCURACY_RATE` decimal(10,6) DEFAULT NULL,
  `S_TABLENAME_MD5` varchar(64) DEFAULT NULL,
  `S_REQUEST_MD5` varchar(32) DEFAULT NULL,
  `I_IS_SIMULATE` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`I_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_mt_wxp_error_info` */

DROP TABLE IF EXISTS `t_mt_wxp_error_info`;

CREATE TABLE `t_mt_wxp_error_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `ems_id` int(11) DEFAULT NULL,
  `wsdl` varchar(128) DEFAULT NULL,
  `method` varchar(64) DEFAULT NULL,
  `tableName` varchar(64) DEFAULT NULL,
  `colName` varchar(64) DEFAULT NULL,
  `seq` varchar(32) DEFAULT NULL,
  `errInfo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/* Function  structure for function  `charindex` */

/*!50003 DROP FUNCTION IF EXISTS `charindex` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `charindex`(in_find_str VARCHAR(255), in_str VARCHAR(512)) RETURNS int(11)
BEGIN
	DECLARE i_pos INT DEFAULT 0;
	SET i_pos = LOCATE(in_find_str, in_str);
	RETURN i_pos;
END */$$
DELIMITER ;

/* Function  structure for function  `len` */

/*!50003 DROP FUNCTION IF EXISTS `len` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `len`(in_str VARCHAR(1024)) RETURNS int(11)
BEGIN
	RETURN CHAR_LENGTH(in_str);
END */$$
DELIMITER ;

/* Function  structure for function  `SP_GET_INCREMENT` */

/*!50003 DROP FUNCTION IF EXISTS `SP_GET_INCREMENT` */;
DELIMITER $$

/*!50003 CREATE FUNCTION `SP_GET_INCREMENT`(tbl VARCHAR(64)) RETURNS decimal(15,0)
BEGIN
   DECLARE sqe NUMERIC(15) DEFAULT NULL;
   DECLARE tbl1 VARCHAR(64) DEFAULT 'Global';
   
   IF tbl IS NOT NULL THEN
    SET tbl1 = tbl;
   END IF;
    SELECT iCurSquence INTO sqe FROM tbPubSequence WHERE sTblName = tbl1; 
    IF sqe IS NULL THEN
      INSERT INTO  tbPubSequence (sTblName,iCurSquence) VALUES (tbl1,2);
      SET sqe = 1;
    ELSE
      UPDATE tbPubSequence SET iCurSquence = iCurSquence + 1 WHERE sTblName = tbl1;  
    END IF;
   RETURN sqe;
END */$$
DELIMITER ;

/* Procedure structure for procedure `PRO_MT_CLEAN_ANY_TASK_DATA` */

/*!50003 DROP PROCEDURE IF EXISTS  `PRO_MT_CLEAN_ANY_TASK_DATA` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `PRO_MT_CLEAN_ANY_TASK_DATA`(IN delTaskIds TEXT)
BEGIN
/*=========================================================
	过程名：	PRO_MT_CLEAN_ANY_TASK_DATA                        	                             
	功能：	清除多个批次的配置数据
	版本：	V1.0.0.0
	创建人：	廖权斌
	创建时间：	2015-11-16	
	参数说明：	入参 delTaskIds 为字符串，是用[,]分隔的多个批次数据的task_id, 仅非null时有效.
	
	版本：	
	修改人：	
	修改时间：	
	修改内容：	
=========================================================*/
    DECLARE DEFAULE_MAX_DEL_LINE INT DEFAULT 10000;
    DECLARE TASK_ID VARCHAR(8) DEFAULT 'task_id';
    DECLARE PK_ID VARCHAR(4) DEFAULT 'id';
    
    DECLARE _delCondition TEXT;
    SET _delCondition = CONCAT(TASK_ID, ' IN(', delTaskIds, ')');
    
    IF delTaskIds IS NOT NULL THEN
        START TRANSACTION;
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('ccic_op_exe_log', 'auto_id', CONCAT('auto_id', ' IN(', delTaskIds, ')'), DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_ems', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_managedelement', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_equipment', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_equipmentholder', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_tp', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_tp2', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_ctp', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_timeslot', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_crossconnection', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_eprotectiongroup', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_protectiongroup', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_subnetworks', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_topologicallink', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_subnetworkconnection', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_snc_tp', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_sncroute', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_toponode', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_redo', 'i_id', _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_fault', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_ws_exe_log', 'I_ID', CONCAT('I_PRESS_ID', ' IN(', delTaskIds, ')'), DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_wxp_error_info', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
        COMMIT;
    END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `PRO_MT_CLEAN_DATA` */

/*!50003 DROP PROCEDURE IF EXISTS  `PRO_MT_CLEAN_DATA` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `PRO_MT_CLEAN_DATA`(IN keepTaskNum INT)
BEGIN
/*=========================================================
	过程名：	PRO_MT_CLEAN_DATA                        	                             
	功能：	清除历史采集的配置数据
	版本：	V1.0.0.0
	创建人：	廖权斌
	创建时间：	2015-11-16	
	参数说明：	入参 keepTaskNum 为整数: 
			N<=0 删除所有配置数据; N>0 保留N批历史采集的配置数据.
			(保留权重为[全部成功]>[部分成功]>[其他], 5天内的[执行中]强制保留)
	
	版本：	
	修改人：	
	修改时间：	
	修改内容：	
=========================================================*/
    DECLARE CMD_UNDO INT DEFAULT 0;
    DECLARE CMD_DOING INT DEFAULT 1; 
    DECLARE CMD_DONE_ALL_OK INT DEFAULT 2; 
    DECLARE CMD_DONE_ANY_OK INT DEFAULT 3; 
    DECLARE CMD_REDOING INT DEFAULT 8;
    
    DECLARE taskId INT DEFAULT -1;
    DECLARE taskIds TEXT DEFAULT ' '; 
    DECLARE cmdNum INT DEFAULT 0;
    DECLARE rs VARCHAR(1024) DEFAULT '';
    
    /* 无指定条件清除数据(keepTaskNum=-1:不清除;  keepTaskNum=0:清除所有) */
    IF keepTaskNum <= 0 THEN
        CALL `PRO_MT_CLEAN_ONE_TASK_DATA`(keepTaskNum);
        
    /* 指定条件清除数据(先筛选需要删除的命令ID, 再执行清除) */
    ELSE
        SET taskIds = ' ';
        
        /* 选取执行失败的命令ID */
        SET rs = (SELECT GROUP_CONCAT(auto_id) FROM ccic_op_exe_log 
                    WHERE op_flag NOT IN (CMD_UNDO, CMD_DOING, CMD_DONE_ALL_OK, CMD_DONE_ANY_OK, CMD_REDOING));
        IF rs IS NOT NULL THEN
            SET taskIds = CONCAT(taskIds, rs, ',');
        END IF;
        
        /* 选取执行时长超过5天还未完成的命令ID */
        SET rs = (SELECT GROUP_CONCAT(auto_id) FROM ccic_op_exe_log 
                    WHERE op_flag IN (CMD_DOING, CMD_REDOING) AND TIMESTAMPDIFF(SECOND, accept_time, NOW()) > 432000);
        IF rs IS NOT NULL THEN
            SET taskIds = CONCAT(taskIds, rs, ',');
        END IF;
        
        /* 
         * 从执行[成功/部分成功]的命令中, 根据[保留数]筛选应该删除的命令ID.
         *
         * 命令保留优先级(依次筛选, 直到最后剩下的命令数 <= 保留数):
         *   1. 成功 > 部分成功
         *   2. 完成时间越接近当前时间, 优先度越高
         */
        SET cmdNum = (SELECT COUNT(1) FROM ccic_op_exe_log WHERE OP_FLAG = CMD_DONE_ALL_OK);
        IF cmdNum >= keepTaskNum THEN
            SET rs = (SELECT GROUP_CONCAT(auto_id) FROM ccic_op_exe_log WHERE op_flag = CMD_DONE_ANY_OK);
            IF rs IS NOT NULL THEN
                SET taskIds = CONCAT(taskIds, rs, ',');
            END IF;
            
            SET rs = (SELECT GROUP_CONCAT(auto_id) FROM ccic_op_exe_log 
                        WHERE op_flag = CMD_DONE_All_OK AND auto_id NOT IN (
                          SELECT auto_id FROM (
                            SELECT auto_id FROM ccic_op_exe_log WHERE op_flag = CMD_DONE_All_OK 
                              ORDER BY finish_time DESC LIMIT keepTaskNum) 
                          AS t));
            IF rs IS NOT NULL THEN
                SET taskIds = CONCAT(taskIds, rs, ',');
            END IF;
            
        ELSE
            SET keepTaskNum = keepTaskNum - cmdNum;
            SET rs = (SELECT GROUP_CONCAT(auto_id) FROM ccic_op_exe_log 
                        WHERE op_flag = CMD_DONE_ANY_OK AND auto_id NOT IN (
                          SELECT auto_id FROM (
                            SELECT auto_id FROM ccic_op_exe_log WHERE op_flag = CMD_DONE_ANY_OK 
                              ORDER BY finish_time DESC LIMIT keepTaskNum) 
                          AS t));
            IF rs IS NOT NULL THEN
                SET taskIds = CONCAT(taskIds, rs, ',');
            END IF;
        
        END IF;
        
        /* 命令ID选择完成, 执行数据清除 */
        SET taskIds = CONCAT(taskIds, '-1 ');
        CALL PRO_MT_CLEAN_ANY_TASK_DATA(taskIds);
    END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `PRO_MT_CLEAN_ONE_TASK_DATA` */

/*!50003 DROP PROCEDURE IF EXISTS  `PRO_MT_CLEAN_ONE_TASK_DATA` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `PRO_MT_CLEAN_ONE_TASK_DATA`(IN delTaskId INT)
BEGIN
/*=========================================================
	过程名：	PRO_MT_CLEAN_ONE_TASK_DATA                        	                             
	功能：	清除一个批次的配置数据
	版本：	V1.0.0.0
	创建人：	廖权斌
	创建时间：	2015-11-16	
	参数说明：	入参 delTaskId 为整数，是某个批次数据的task_id， 仅 >0 时有效.
	
	版本：	
	修改人：	
	修改时间：	
	修改内容：	
=========================================================*/
    DECLARE DEFAULE_MAX_DEL_LINE INT DEFAULT 10000;
    DECLARE TASK_ID VARCHAR(8) DEFAULT 'task_id';
    DECLARE PK_ID VARCHAR(4) DEFAULT 'id';
    
    DECLARE _delCondition TEXT;
    
    
    IF delTaskId > 0 THEN
        SET _delCondition = CONCAT(TASK_ID, ' = ', delTaskId);
        
        START TRANSACTION;
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('ccic_op_exe_log', 'auto_id', CONCAT('auto_id', ' = ', delTaskId), DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_ems', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_managedelement', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_equipment', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_equipmentholder', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_tp', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_tp2', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_ctp', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_timeslot', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_crossconnection', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_eprotectiongroup', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_protectiongroup', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_subnetworks', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_topologicallink', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_subnetworkconnection', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_snc_tp', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_sncroute', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_toponode', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_redo', 'i_id', _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_fault', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_ws_exe_log', 'I_ID', CONCAT('I_PRESS_ID', ' = ', delTaskId), DEFAULE_MAX_DEL_LINE);
            CALL `PRO_MT_CLEAN_SUB_TASK_DATA`('t_mt_wxp_error_info', PK_ID, _delCondition, DEFAULE_MAX_DEL_LINE);
        COMMIT;
        
    ELSEIF delTaskId = 0 THEN
        START TRANSACTION;
            TRUNCATE TABLE ccic_op_exe_log;
            TRUNCATE TABLE t_mt_ems;
            TRUNCATE TABLE t_mt_managedelement;
            TRUNCATE TABLE t_mt_equipment;
            TRUNCATE TABLE t_mt_equipmentholder;
            TRUNCATE TABLE t_mt_tp;
            TRUNCATE TABLE t_mt_tp2;
            TRUNCATE TABLE t_mt_ctp;
            TRUNCATE TABLE t_mt_timeslot;
            TRUNCATE TABLE t_mt_crossconnection;
            TRUNCATE TABLE t_mt_eprotectiongroup;
            TRUNCATE TABLE t_mt_protectiongroup;
            TRUNCATE TABLE t_mt_subnetworks;
            TRUNCATE TABLE t_mt_topologicallink;
            TRUNCATE TABLE t_mt_subnetworkconnection;
            TRUNCATE TABLE t_mt_snc_tp;
            TRUNCATE TABLE t_mt_sncroute;
            TRUNCATE TABLE t_mt_toponode;
            TRUNCATE TABLE t_mt_redo;
            TRUNCATE TABLE t_mt_fault;
            TRUNCATE TABLE t_mt_ws_exe_log;
            TRUNCATE TABLE t_mt_wxp_error_info;
        COMMIT;
        
    END IF;
END */$$
DELIMITER ;

/* Procedure structure for procedure `PRO_MT_CLEAN_SUB_TASK_DATA` */

/*!50003 DROP PROCEDURE IF EXISTS  `PRO_MT_CLEAN_SUB_TASK_DATA` */;

DELIMITER $$

/*!50003 CREATE PROCEDURE `PRO_MT_CLEAN_SUB_TASK_DATA`(
    IN tableName VARCHAR(64), 
    IN pkColName VARCHAR(64), 
    IN delCondition TEXT, 
    IN maxDelLine INT)
BEGIN
/*=========================================================
	过程名：	PRO_MT_CLEAN_SUB_TASK_DATA                        	                             
	功能：	根据指定条件对某个批次的配置数据分段迭代删除，避免同时删除引起连接超时导致失败.
	版本：	V1.0.0.0
	创建人：	廖权斌
	创建时间：	2015-11-16	
	参数说明：	tableName: 被删除的数据表名.
			pkColName: 被删除的数据表的主键列名.
			delCondition: 删除条件.
			maxDelLine 一次最多删除的行数.
	
	版本：	
	修改人：	
	修改时间：	
	修改内容：	
=========================================================*/
    DECLARE DEFAULE_MAX_DEL_LINE INT DEFAULT 10000;
    
    DECLARE _sql TEXT;
    DECLARE _count INT;
    DECLARE _maxId INT;
    DECLARE _minId INT;
    DECLARE _bgnId INT;
    DECLARE _endId INT;
    
    IF (tableName IS NOT NULL) AND (pkColName IS NOT NULL) THEN 
        IF maxDelLine <= 0 THEN
            SET maxDelLine = DEFAULE_MAX_DEL_LINE;
        END IF;
        
        IF (delCondition IS NOT NULL) AND (LOCATE('and', LOWER(TRIM(delCondition))) <= 0) THEN 
            SET delCondition = CONCAT('AND ', delCondition);
        END IF;
        
        /* 查询在删除范围内的 删除总数、最大值、最小值 */
        SET _sql= CONCAT('SELECT COUNT(1) INTO @count FROM ', tableName, ' WHERE 1 = 1 ', delCondition);
        SET @sql = _sql;
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
        SET _count = @count;
        
        SET _sql= CONCAT('SELECT MAX(', pkColName, ') INTO @maxId FROM ', tableName, ' WHERE 1 = 1 ', delCondition);
        SET @sql = _sql;
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
        SET _maxId = IF(@maxId IS NULL, 0, @maxId);
        
        SET _sql= CONCAT('SELECT MIN(', pkColName, ') INTO @minId FROM ', tableName, ' WHERE 1 = 1 ', delCondition);
        SET @sql = _sql;
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
        SET _minId = IF(@minId IS NULL, 0, @minId);
        
        /* 分段迭代删除数据 */
        SET _endId = _minId;
        DEL_DATA: REPEAT
            SET _bgnId = _endId;
            SET _endId = _bgnId + maxDelLine;
            SET _endId = IF (_endId > _maxId, _maxId, _endId);
            SET _sql= CONCAT('DELETE FROM ', tableName, ' WHERE 1 = 1 AND ', 
                                pkColName, ' BETWEEN ', _bgnId, ' AND ', _endId , ' ', delCondition);
            SET @sql = _sql;
            PREPARE stmt FROM @sql;
            EXECUTE stmt;
            DEALLOCATE PREPARE stmt;
        UNTIL _bgnId = _endId END REPEAT DEL_DATA;
 
    END IF;
END */$$
DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
