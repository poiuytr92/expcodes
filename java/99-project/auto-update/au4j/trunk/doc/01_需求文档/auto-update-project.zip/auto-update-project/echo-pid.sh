#!/bin/bash
# ws-collector 

export threadname=$(cat _threadname)
PID=`ps -ef|grep "D$threadname "|grep -v grep|awk '{print $2}'`
if [ -z $PID ];then
    echo "The program $threadname has been stoped."
else
    echo $PID
fi